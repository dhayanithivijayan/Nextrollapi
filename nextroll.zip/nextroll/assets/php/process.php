<?php

$errorMSG = "";

// adv
if (empty($_GET["adv"])) {
    $errorMSG = "Advertisable ID is required ";
} else {
    $adv = trim($_GET["adv"]);
}

// EMAIL
if (empty($_GET["cam"])) {
    $errorMSG .= "Campaign ID is required ";
} else {
    $cam = trim($_GET["cam"]);
}

// MSG SUBJECT
if (empty($_GET["ad"])) {
    $errorMSG .= "Ad ID is required ";
} else {
    $ad =trim($_GET["ad"]);
}


// MESSAGE
if (empty($_GET["rcode"])) {
    $errorMSG .= "rcode is required ";
} else {
    $rcode = trim($_GET["rcode"]);
}

if ($rcode==1){
	        //VRPZHBR5XJFDBJ4344Z2I2
			  $curl = curl_init();
			  curl_setopt_array($curl, array(
			  CURLOPT_URL => "https://services.adroll.com/api/v1/advertisable/get?apikey=9EB1WqdP69gyNzsY2Z3FejF43Iz5lX31&advertisable=".$adv,
			  CURLOPT_RETURNTRANSFER => true,
			  CURLOPT_ENCODING => "",
			  CURLOPT_MAXREDIRS => 10,
			  CURLOPT_TIMEOUT => 30,
			  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			  CURLOPT_CUSTOMREQUEST => "GET",
			  CURLOPT_HTTPHEADER => array(
				"apikey: xzMAcKmHxvQigFaGzIOEAOGZdEgNnfy7",
				"authorization: Basic YmFsYWNoYW5kcmFuLmFydW11Z2FtQGFkcm9sbC5jb206SU9QRVgjMTIz",
				"cache-control: no-cache",
				"postman-token: 3a5fdf40-3964-4314-b6db-a3784c690ebc",
				"x-vault-token: s.va88WZ5KAgvQvklSc7ceBfO4"
			  ),
			  ));

			$response = curl_exec($curl);
			$err = curl_error($curl);

			curl_close($curl);

			if ($err) {
			  echo "cURL Error #:" . $err;
			} else {
			  echo $response;
			}
}else if ($rcode==2){
	         
			 //ETAPF22GRJEQZMLDJ3MBJL
	
			$curl = curl_init();
			curl_setopt_array($curl, array(
			  CURLOPT_URL => "https://services.adroll.com/api/v1/campaign/get?apikey=9EB1WqdP69gyNzsY2Z3FejF43Iz5lX31&campaign=".$cam,
			  CURLOPT_RETURNTRANSFER => true,
			  CURLOPT_ENCODING => "",
			  CURLOPT_MAXREDIRS => 10,
			  CURLOPT_TIMEOUT => 30,
			  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			  CURLOPT_CUSTOMREQUEST => "GET",
			  CURLOPT_HTTPHEADER => array(
				"authorization: Basic YmFsYWNoYW5kcmFuLmFydW11Z2FtQGFkcm9sbC5jb206SU9QRVgjMTIz",	
				"cache-control: no-cache",
				"postman-token: 6a0814ac-8e5b-a7d5-b31d-a994a7d1eec0"
			  ),
			));
			$response = curl_exec($curl);
			$err = curl_error($curl);
			curl_close($curl);
			if ($err) {
			  echo "cURL Error #:" . $err;
			} else {
			  echo $response;
			}
	
}else if ($rcode==3){
	     //2ODJGA7N2BB4DCDBM3EEOO
	    $curl = curl_init();
		curl_setopt_array($curl, array(
		  CURLOPT_URL => "https://services.adroll.com/api/v1/ad/get?apikey=9EB1WqdP69gyNzsY2Z3FejF43Iz5lX31&ad=".$ad,
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_ENCODING => "",
		  CURLOPT_MAXREDIRS => 10,
		  CURLOPT_TIMEOUT => 30,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => "GET",
		  CURLOPT_HTTPHEADER => array(
			"authorization: Basic YmFsYWNoYW5kcmFuLmFydW11Z2FtQGFkcm9sbC5jb206SU9QRVgjMTIz",
			"cache-control: no-cache",
			"postman-token: de103a94-017d-bf8b-2866-de456cf2a496"
		  ),
		));
		$response = curl_exec($curl);
		$err = curl_error($curl);
		curl_close($curl);
		if ($err) {
		  echo "cURL Error #:" . $err;
		} else {
		  echo $response;
		}
	
}
?>