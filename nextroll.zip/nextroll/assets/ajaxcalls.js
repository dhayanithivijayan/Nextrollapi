


function getadvdetails(){
    // Initiate Variables With Form Content
    var adv = $("#adv").val(); 
    $.ajax({
        type: "GET",
        url: "assets/php/process.php",
        data: "adv=" + adv + "&rcode=1",
        success : function(text){
			var obj = jQuery.parseJSON( text );
			$('#advmessage').val(text);
			$('#orgid').val(obj.results.organization);
			$('#fbpage').val(obj.results.fbx_page_url);
			$('#inspectpage').val(obj.results.inspect_path);
			$('#createddate').val(obj.results.created_date);
			$('#website').val(obj.results.url);
            /*if (text == "success"){
               $('#advmessage').val('foobar'); 
            } else {
               alert(text);
            }*/
        }
    });
}

function getcampaigndetails(){
    // Initiate Variables With Form Content
    var cam = $("#cam").val(); 
       $.ajax({
        type: "GET",
        url: "assets/php/process.php",
        data: "cam=" + cam + "&rcode=2",
        success : function(text){
			var obj = jQuery.parseJSON( text );
			$('#cammessage').val(text); 
			$('#name').val(obj.results.name);
			$('#created_date').val(obj.results.created_date);
			$('#budget').val(obj.results.budget);
			$('#start_date').val(obj.results.start_date);
			$('#campaign_type').val(obj.results.campaign_type);			
			
           /* if (text == "success"){
               $('#cammessage').val('foobar'); 
            } else {
               alert(text);
            }*/
        }
    });
}


function getaddetails(){
    // Initiate Variables With Form Content
    var ad = $("#ad").val(); 
    $.ajax({
        type: "GET",
        url: "assets/php/process.php",
        data: "ad=" + ad + "&rcode=3",
        success : function(text){
		var obj = jQuery.parseJSON( text );
		
			$('#headline').val(obj.results.headline);
			$('#destination_url').val(obj.results.destination_url);
			$('#ad_format').val(obj.results.ad_format);
			$('#status').val(obj.results.status);	
            $('#body').val(obj.results.body); 
			$('#adimage').attr("src",obj.results.src);			
		    $('#admessage').val(text); 
        
        }
    });
}

function formSuccess(){
    $("#contactForm")[0].reset();
    submitMSG(true, "Message Submitted!")
}

function formError(){
    $("#contactForm").removeClass().addClass('shake animated').one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function(){
        $(this).removeClass();
    });
}

function submitMSG(valid, msg){
    if(valid){
        var msgClasses = "h3 text-center tada animated text-success";
    } else {
        var msgClasses = "h3 text-center text-danger";
    }
    $("#msgSubmit").removeClass().addClass(msgClasses).text(msg);
}